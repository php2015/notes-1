

const state = {
  cartList: JSON.parse(localStorage.getItem('cart-list') || '[]')
}

export default state