

const getters = {
  cartListLength(state) {
    return state.cartList.length;
  },
  checkedCartList(state) {
    return state.cartList.filter(item => item.isChecked);
  },
  checkedCartListLength(state, getters) {
    return getters.checkedCartList.length;
  },
  isAllChecked(state, getters) { // 是否全选 get方法
    return getters.cartListLength == getters.checkedCartListLength && getters.checkedCartListLength;
  },
  totalPrice(state, getters) {
    return getters.checkedCartList.reduce((prev, next) => prev + next.lowNowPrice * next.count, 0);
  }
}

export default getters