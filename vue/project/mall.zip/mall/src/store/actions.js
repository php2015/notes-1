

const actions = {
  addToCart(context, product) { // 加入购物车功能
    return new Promise((resolve, reject) => {

      for (var i = 0; i < context.state.cartList.length; i++) {
        if (context.state.cartList[i].iid == product.iid) {
          context.commit('ADDTOCART', i);
          // 如果已经加过 把index值传过去 让cartList对应的该项数量+1即可
          resolve('该商品数量+1')
          break;
        }
      }
      if (i == context.state.cartList.length) {
        product.count = 1;
        context.commit('ADDTOCART', product); // 如果没有加过 直接push该商品
        resolve('已成功添加该商品')
      }

    })
  },
  toggleItem(context, index) { // 购物车页面商品是否勾选功能
    context.commit('TOGGLEITEM', index);
  },
  toggleAll(context, allCheckedStatus) {
    context.commit('TOGGLEALL', allCheckedStatus)
  }
}

export default actions