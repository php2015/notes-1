

const mutations = {
  ADDTOCART(state, payload) { // 加入购物车功能
    if (typeof payload == 'number') { // 如果传过来的payload是数字 说已经已经加过 让对应的项+1即可
      state.cartList[payload].count += 1;
    } else {
      state.cartList.push(payload) // 否则没有加过 直接push
    }
  },
  TOGGLEITEM(state, index) { // 购物车页面商品是否勾选功能
    state.cartList[index].isChecked = !state.cartList[index].isChecked;
  },
  TOGGLEALL(state, allCheckedStatus) {
    state.cartList.forEach(item => {
      item.isChecked = allCheckedStatus;
    });
  }
}

export default mutations