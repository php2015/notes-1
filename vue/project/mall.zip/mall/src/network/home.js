
// Home主页组件所用需要用到网络请求的地方都在本模块里

import { request } from './request';

export function getHomeMultidata(config) { // 轮播图及轮播图下面的四个推荐数据
  return request({
    url: "/home/multidata"
  })
}

export function getHomeGoods(type, page) { // 首页下方的goodlist数据
  return request({
    url: "/home/data",
    params: {
      type,
      page
    }
  })
}