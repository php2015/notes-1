import Vue from 'vue'
import App from './App.vue'

Vue.config.productionTip = false

// 图片懒加载
import VueLazyLoad from 'vue-lazyload';
Vue.use(VueLazyLoad, {
  loading: require('./assets/img/lazyload.png'),
});


// 导入mint-ui 本项目中用到的组件有[Swipe, Toast, Indicator]
import MintUI from 'mint-ui'
import 'mint-ui/lib/style.css'
Vue.use(MintUI)

// fastclick
// import Fastclick from 'fastclick';
// Fastclick.attach(document.body)

import router from './router';
import store from './store';

new Vue({
  router,
  store,
  render: h => h(App),
}).$mount('#app')
