
// 本模块用于时间的显示格式

import moment from 'moment';

export function showDateWithFormat(val, format) {
  return moment(val).format(format || "YYYY-MM-DD HH:mm:ss");
}