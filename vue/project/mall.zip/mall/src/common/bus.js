

// 中央事件总线

import Vue from 'vue';
const bus = new Vue();
export default bus