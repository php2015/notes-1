<template>
  <div id="main-tab-bar">
    <tab-bar>

      <template v-slot>
        <tab-bar-item path="/home" activeColor="#f44">
          <template v-slot:item-icon>
            <span class="iconfont icon-shouye"></span>
          </template>
          <template v-slot:item-txt>
            <div>首页</div>
          </template>
        </tab-bar-item>

        <tab-bar-item path="/category" activeColor="#f44">
          <template v-slot:item-icon>
            <span class="iconfont icon-fenlei"></span>
          </template>
          <template v-slot:item-txt>
            <div>分类</div>
          </template>
        </tab-bar-item>

        <tab-bar-item path="/cart" activeColor="#f44">
          <template v-slot:item-icon>
            <span class="iconfont icon-gouwuchekong"></span>
          </template>
          <template v-slot:item-txt>
            <div>购物车</div>
          </template>
        </tab-bar-item>

        <tab-bar-item path="/profile" activeColor="#f44">
          <template v-slot:item-icon>
            <span class="iconfont icon-wode"></span>
          </template>
          <template v-slot:item-txt>
            <div>我的</div>
          </template>
        </tab-bar-item>
      </template>
      
    </tab-bar>
  </div>
</template>

<script>
// 导入公共组件
import TabBar from "components/common/tabBar/TabBar";
import TabBarItem from "components/common/tabBar/TabBarItem";

export default {
  name: "MainTabBar",
  components: {
    TabBar,
    TabBarItem,
  },
};
</script>

<style scoped>
.iconfont {
  font-size: 18px;
}
#main-tab-bar {
  user-select: none;
  height: 49px;
  position: fixed;
  bottom: 0;
  left: 0;
  right: 0;
  z-index: 9;
}
</style>