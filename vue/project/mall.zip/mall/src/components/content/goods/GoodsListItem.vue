<template>
  <div class="goods-list-item" @click="itemClick">
    <img v-lazy="imgURL" alt="" @load="refreshBS" :key="item.iid">
    <div>
      <p class="item-title">{{item.title}}</p>
      <span class="item-price">{{item.price}}</span>
      <i class="iconfont icon-shoucang"></i>
      <span class="item-collect">{{item.cfav}}</span>
    </div>
  </div>
</template>

<script>
// 导入公共JS模块
import Bus from "common/bus"; // 中央事件总线

export default {
  name: "GoodsListItem",
  props: {
    item: {
      type: Object,
      default() {
        return {};
      },
    },
    index: {
      type: Number,
      default: 0,
    },
  },
  computed: {
    imgURL() {
      return this.item.img || this.item.image || this.item.show.img;
    },
  },
  methods: {
    refreshBS() {
      if (this.$route.path.includes("/home")) {
        Bus.$emit("refreshFromHomeGoodsListItem");
      } else if (this.$route.path.includes("/detail")) {
        Bus.$emit("refreshFromDetailGoodsListItem");
      } else if (this.$route.path.includes("/category")) {
        Bus.$emit("categoryRefresh");
      }
    },
    itemClick() {
      if (
        this.$route.path.includes("/home") ||
        this.$route.path.includes("/category")
      ) {
        this.$router.push("/detail/" + this.item.iid);
      }
    },
  },
};
</script>

<style scoped>
.goods-list-item {
  width: 46%;
  font-size: 14px;
  text-align: center;
  margin-bottom: 4px;
}

.goods-list-item img {
  width: 100%;
  border-radius: 5px;
}

.item-title {
  white-space: nowrap;
  text-overflow: ellipsis;
  overflow: hidden;
  margin-top: 6px;
  margin-bottom: 5px;
}

.item-price {
  font-size: 15px;
  color: var(--color-high-text);
  margin-right: 8px;
}

.item-collect {
  font-size: 15px;
}
</style>