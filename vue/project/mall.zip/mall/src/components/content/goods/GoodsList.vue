<template>
  <div class="goods-list">
    <h3 class="more-recommend" :class="{block:headerIsShow}">更多推荐</h3>
    <div class="item-wrap">
      <goods-list-item v-for="(item, index) in items" :key="index" :item="item" :index="index" />
    </div>
  </div>
</template>

<script>
import GoodsListItem from "./GoodsListItem";

export default {
  name: "GoodsList",
  components: {
    GoodsListItem,
  },
  props: {
    items: {
      type: Array,
      default() {
        return [];
      },
    },
    headerIsShow: {
      type: Boolean,
      default: false,
    },
  },
};
</script>

<style scoped>
.item-wrap {
  display: flex;
  flex-flow: row wrap;
  justify-content: space-evenly;
  padding-bottom: 60px;
  width: 100%;
}

.more-recommend {
  padding: 20px;
  color: var(--color-high-text);
  display: none;
}

.block {
  display: block;
}
</style>