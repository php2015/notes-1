<template>
  <div class="back-top">
    <span class="iconfont icon-huidaodingbu"></span>
  </div>
</template>

<script>
export default {
  name: "BackTop",
};
</script>

<style scoped>
.back-top {
  position: fixed;
  z-index: 18;
  background: #fff;
  bottom: 59px;
  right: 10px;
  height: 43px;
  width: 43px;
  border-radius: 50%;
  display: flex;
  align-items: center;
  justify-content: center;
  border: 1px solid #eee;
}
.icon-huidaodingbu {
  color: var(--color-high-text);
  font-weight: bold;
  font-size: 20px;
}
</style>