<template>
  <div class="swiper">
    <mt-swipe :auto="interval">
      <mt-swipe-item v-for="(item, index) in swiperImages" :key="index">
        <img :src="item.image?item.image:item" alt="" @load="refreshBS(index)">
      </mt-swipe-item>
    </mt-swipe>
  </div>
</template>

<script>
import Vue from "vue";
import { Swipe, SwipeItem } from "mint-ui";
Vue.component(Swipe.name, Swipe);
Vue.component(SwipeItem.name, SwipeItem);

import Bus from "common/bus";

export default {
  name: "Swiper",
  props: {
    swiperImages: {
      type: Array,
      default() {
        return [];
      },
    },
    interval: {
      type: Number,
      default: 3000,
    },
  },
  methods: {
    refreshBS(index) {
      if (index == 0) {
        if (this.$route.path.includes("/home")) {
          // console.log("/home");
          Bus.$emit("refreshFromHomeSwiper");
          this.$emit("getTabControlOffsetTop");
        } else if (this.$route.path.includes("/detail")) {
          // console.log("/detail");
          Bus.$emit("refreshFromDetailSwiper");
        }
      }
    },
  },
};
</script>

<style scoped>
img {
  width: 100%;
}
</style>

<style>
.swiper .mint-swipe-indicators .mint-swipe-indicator {
  background: #fff;
  opacity: 0.8;
}

.swiper .mint-swipe-indicators .is-active {
  background: var(--color-high-text);
  opacity: 1;
}
</style>