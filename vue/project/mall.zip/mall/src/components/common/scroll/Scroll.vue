<template>
  <div class="better-scroll-wrapper">
    <div class="content">
      <slot></slot>
    </div>
  </div>
</template>

<script>
import BScroll from "better-scroll";

export default {
  name: "Scroll",
  props: {
    probeType: {
      type: Number,
      default: 0,
    },
    pullUpLoad: {
      type: Boolean,
      default: false,
    },
  },
  data() {
    return {
      bs: {},
    };
  },
  mounted() {
    // this.$nextTick(function () {
    this.bs = new BScroll(".better-scroll-wrapper", {
      probeType: this.probeType,
      pullUpLoad: this.pullUpLoad,
      click: true,
      disableTouch: false,
      // eventPassthrough: "vertical",
      observeDOM: true,
    });

    // 监听Y轴滚动位置
    if (this.probeType == 2 || this.probeType == 3) {
      this.bs.on("scroll", (position) => {
        this.$emit("scroll", position.y);
      });
    }

    // 下拉加载更多
    if (this.pullUpLoad) {
      this.bs.on("pullingUp", () => {
        this.$emit("pullingUp");
      });
    }
    // });
  },
  methods: {
    scrollTo(x, y, time = 400) {
      this.bs.scrollTo(x, y, time);
    },
    finishPullUp() {
      this.bs.finishPullUp();
    },
    refresh() {
      this.bs.refresh();
    },
  },
};
</script>

<style scoped>
.better-scroll-wrapper {
  overflow: hidden;
}
</style>