<template>
  <div class="tab-bar-item" @click="goToView" :style='activeStyle'>
    <slot name="item-icon"></slot>
    <slot name="item-txt"></slot>
  </div>
</template>

<script>
export default {
  name: "TabBarItem",
  props: {
    path: {
      type: String,
      default: "",
    },
    activeColor: {
      type: String,
      default: "#44f",
    },
  },
  computed: {
    isActive() {
      return this.$route.path.includes(this.path);
    },
    activeStyle() {
      return this.isActive ? { color: this.activeColor } : {};
    },
  },
  methods: {
    goToView() {
      if (!this.isActive) {
        this.$router.push(this.path);
      }
    },
  },
};
</script>

<style scoped>
.tab-bar-item {
  flex-grow: 1;
  text-align: center;
  margin-top: 6px;
  font-size: 14px;
}
</style>