<template>
  <ul class="cart-list">
    <cart-list-item v-for="(item, index) in $store.state.cartList" :key="index" :item="item" :index="index" />
  </ul>
</template>

<script>
import CartListItem from "./CartListItem";

export default {
  name: "CartList",
  components: {
    CartListItem,
  },
};
</script>


<style scoped>
.cart-list {
  list-style: none;
}
</style>