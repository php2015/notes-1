<template>
  <div class="bottom-bar">

    <div class="left">
      <label @click="toggleAll">
        <span class="iconfont icon-gouxuan1" :class="{ticked:isAllChecked}"></span>
        <i>全选</i>
      </label>
      <div class="total">
        合计：<span class="total-price">{{totalPrice | cnyFormat}}</span>
      </div>
    </div>

    <div class="checkout">
      去结算({{checkedCartListLength}})
    </div>
  </div>
</template>

<script>
// 导入vuex相关
import { mapGetters } from "vuex";

export default {
  name: "CartBottomBar",
  computed: {
    ...mapGetters(["checkedCartListLength", "isAllChecked", "totalPrice"]),
  },
  filters: {
    cnyFormat(n) {
      return "¥" + n.toFixed(2);
    },
  },
  methods: {
    toggleAll() {
      this.$store.dispatch("toggleAll", !this.isAllChecked);
    },
  },
};
</script>

<style scoped>
.bottom-bar {
  position: fixed;
  bottom: 49px;
  left: 0;
  right: 0;
  /* background: red; */
  height: 40px;
  line-height: 40px;
}
i {
  font-style: normal;
}
.checkout {
  position: absolute;
  width: 100px;
  height: 40px;
  right: 0;
  bottom: 0;
  background: orange;
  text-align: center;
  color: #fff;
}
.left {
  display: flex;
  padding-left: 20px;
  background: #ededed;
}
.left label {
  margin-right: 20px;
  color: #8a8a8a;
}
.iconfont {
  margin-right: 6px;
}
.total-price {
  color: orange;
  font-weight: bold;
}
.ticked {
  color: var(--color-high-text);
}
</style>