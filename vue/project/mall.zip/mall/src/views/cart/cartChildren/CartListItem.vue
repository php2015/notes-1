<template>
  <li class="list-item">

    <div class="left-part">
      <span class="iconfont icon-gouxuan1" :class="{ticked:item.isChecked}" @click="toggleItem(index)"></span>
      <img :src="item.imgURL" alt="" @load='refreshBS'>
    </div>

    <div class="right-part">
      <div class="title">{{item.title}}</div>
      <div class="desc">{{item.desc}}</div>
      <div class="price-wrap">
        <div class="price">{{item.lowNowPrice | cnyFormat}}</div>
        <div class="counter">×{{item.count}}</div>
      </div>
    </div>

  </li>
</template>

<script>
import Bus from "common/bus";

export default {
  name: "CartListItem",
  props: {
    item: {
      type: Object,
      default() {
        return {};
      },
    },
    index: {
      type: Number,
      default: -1,
    },
  },
  data() {
    return {};
  },
  filters: {
    cnyFormat(price) {
      return "¥" + price;
    },
  },
  methods: {
    refreshBS() {
      Bus.$emit("refreshBSFromCartListItem");
    },
    toggleItem(index) {
      this.$store.dispatch("toggleItem", index);
    },
  },
};
</script>

<style scoped>
.list-item {
  padding: 10px;
  border-bottom: 1px solid #eee;
  height: 140px;
  width: 100%;
}
.list-item > div {
  height: 100%;
}
.left-part {
  float: left;
  /* background: blue; */
  margin-right: 12px;
}
.left-part img {
  height: 120px;
  border-radius: 4px;
  vertical-align: middle;
}
.iconfont {
  margin-right: 6px;
}
.right-part {
  /* background: red; */
  height: 100px;
  height: 100px;
  overflow: hidden;
  font-size: 14px;
  position: relative;
}
.title,
.desc {
  text-overflow: ellipsis;
  white-space: nowrap;
  overflow: hidden;
  margin-bottom: 20px;
}
.desc {
  color: #aaa;
}
.price-wrap {
  display: flex;
  justify-content: space-between;
  padding-right: 12px;
  /* background: red; */
  position: absolute;
  bottom: 0;
  left: 0;
  right: 0;
  height: 44px;
  line-height: 60px;
  vertical-align: bottom;
}
.price {
  font-size: 24px;
  color: orange;
}
.counter {
  font-size: 20px;
}
.ticked {
  color: var(--color-high-text);
}
</style>