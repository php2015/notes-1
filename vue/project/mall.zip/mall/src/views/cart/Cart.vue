<template>
  <div id="cart">
    <nav-bar class="cart-nav-bar">
      <template v-slot:center>
        <div>购物车({{cartListLength}})</div>
      </template>
    </nav-bar>

      <scroll class="scroll" ref="scroll" v-show="cartListLength">
        <cart-list />
      </scroll>
      <div v-if="!cartListLength" class="no-item">
        暂未有任何商品。。
      </div>
      <cart-bottom-bar />
  </div>
</template>

<script>
// 导入子组件
import CartList from "./cartChildren/CartList";
import CartBottomBar from "./cartChildren/CartBottomBar";

// 导入公共组件
import NavBar from "components/common/navBar/NavBar";
import Scroll from "components/common/scroll/Scroll";

// 导入公共JS模块
import Bus from "common/bus"; // 中央事件总线
import { debounce } from "common/utils"; // 防抖函数

// 导入vuex相关
import { mapState, mapGetters } from "vuex";

export default {
  name: "Cart",
  created() {
    // console.log("Cart created");
  },
  mounted() {
    this.refresh = debounce(this.$refs.scroll.refresh);
    Bus.$on("refreshBSFromCartListItem", () => {
      this.refresh;
    });
  },
  computed: {
    ...mapState(["cartList"]),
    ...mapGetters(["cartListLength"]),
  },
  components: {
    NavBar,
    Scroll,
    CartList,
    CartBottomBar,
  },
  activated() {
    this.refresh();
  },
  watch: {
    // 数据一旦发现变化 存入localStorage
    cartList: {
      deep: true,
      handler: (newVal) => {
        localStorage.setItem("cart-list", JSON.stringify(newVal));
      },
    },
  },
};
</script>

<style scoped>
.cart-nav-bar {
  background: var(--color-tint);
  color: #fff;
  position: relative;
  z-index: 8;
}
.scroll {
  height: calc(100vh - 133px);
}
.no-item {
  margin: 40px auto;
  text-align: center;
  font-size: 14px;
  color: var(--color-high-text);
  font-weight: bold;
}
</style>