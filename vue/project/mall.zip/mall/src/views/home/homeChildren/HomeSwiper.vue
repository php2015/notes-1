<template>
  <div class="home-swiper">
    <mt-swipe :auto="3000">
      <mt-swipe-item v-for="(item, index) in swiperImages" :key="index">
        <!-- <a :href="item.link"> -->
          <img :src="item.image" :alt="item.title" @load="refreshBS(index)">
        <!-- </a> -->
      </mt-swipe-item>
    </mt-swipe>
  </div>
</template>

<script>
import Vue from "vue";
import { Swipe, SwipeItem } from "mint-ui";
Vue.component(Swipe.name, Swipe);
Vue.component(SwipeItem.name, SwipeItem);

export default {
  name: "HomeSwiper",
  props: {
    swiperImages: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  methods: {
    refreshBS(index) {
      // console.log("refreshBS");
      if (index == 1) {
        this.$emit("refreshBS");
        this.$emit("getTabControlOffsetTop");
      }
    },
  },
};
</script>

<style scoped>
.home-swiper {
  height: 52vw;
  /* 这个是根据图片的宽高比决定的 390/750 */
}
.home-swiper img {
  width: 100%;
  /* display: block; */
}
</style>

<style>
.home-swiper .mint-swipe-indicator {
  background: #fff;
  opacity: 0.8;
}

.home-swiper .is-active {
  background: var(--color-high-text);
  opacity: 1;
}
</style>