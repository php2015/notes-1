<template>
  <div class="home-recommend">
    <div v-for="(item, index) in recommend" :key="index" class="recommend-item">
        <img :src="item.image" alt="" @load="refreshBS">
        <div>{{item.title}}</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "HomeRecommend",
  props: {
    recommend: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  methods: {
    refreshBS() {
      this.$emit("refreshBS");
    },
  },
};
</script>

<style scoped>
.home-recommend {
  display: flex;
  text-align: center;
  font-size: 12px;
  padding: 15px 0;
  border-bottom: 6px solid #eee;
}

.recommend-item {
  flex: 1;
}

.recommend-item img {
  width: 70px;
  height: 70px;
  margin-bottom: 10px;
}
</style>