<template>
  <div class="home-feature">
    <a href="https://act.mogujie.com/zzlx67">
      <img src="@/assets/img/home/recommend_bg.jpg" alt="" @load="refreshBS">
    </a>
  </div>
</template>

<script>
export default {
  name: "HomeFeature",
  methods: {
    refreshBS() {
      this.$emit("refreshBS");
    },
  },
};
</script>

<style scoped>
.home-feature img {
  width: 100%;
}
</style>