<template>
  <div id="home">

  <nav-bar class="home-nav-bar">
    <template v-slot:center>
      购物街
    </template>
  </nav-bar>

  <tab-control :titles="['流行','新款','精选']" @setIndex="setIndex" ref="topTabControl" class="top-tab-control" v-show="topTabControlIsShow" />

  <scroll :probe-type="3" :pull-up-load="true" @scroll="scroll" @pullingUp="pullingUp" ref="scroll" class="scroll">
    <home-swiper @refreshBS="refreshBS" class="home-swiper" :swiper-images="swiperImages" @getTabControlOffsetTop="getTabControlOffsetTop" />
    <home-recommend :recommend="recommend" @refreshBS="refreshBS" />
    <home-feature @refreshBS="refreshBS" />
    <tab-control :titles="['流行','新款','精选']" @setIndex="setIndex" ref="tabControl" />
    <goods-list :items="items" class="goods-list" />
  </scroll>

  <back-top @click.native="backToTop" v-show="BackTopIsShow" />
  
  </div>
</template>

<script>
// 导入公共组件
import NavBar from "components/common/navBar/NavBar";
import TabControl from "components/content/tabControl/TabControl";
import GoodsList from "components/content/goods/GoodsList";
import Scroll from "components/common/scroll/Scroll";
import BackTop from "components/content/backTop/BackTop";

// 导入子组件
import HomeRecommend from "./homeChildren/HomeRecommend";
import HomeFeature from "./homeChildren/HomeFeature";
import HomeSwiper from "./homeChildren/HomeSwiper";

// 导入网络请求相关方法
import { getHomeMultidata, getHomeGoods } from "network/home";

// 导入公共JS模块
import Bus from "common/bus"; // 中央事件总线
import { debounce } from "common/utils"; // 防抖函数
import { Indicator } from "mint-ui"; // 加载圈圈图标

export default {
  name: "Home",
  data() {
    return {
      swiperImages: [],
      recommend: [],
      goods: {
        pop: { page: 0, list: [] },
        new: { page: 0, list: [] },
        sell: { page: 0, list: [] },
      },
      currentType: "pop",
      refresh: null,
      BackTopIsShow: false,
      topTabControlIsShow: false,
      tabControlOffsetTop: 0,
      tabCurrentIndex: 0,
      currentPagePositionY: 0,
    };
  },
  computed: {
    items() {
      return this.goods[this.currentType].list;
    },
  },
  created() {
    console.log("Home created");
    // 发送网络请求
    this.getHomeMultidata(); // 轮播图及轮播图下面的四个推荐数据

    this.getHomeGoods("pop"); // 首页下方的goodlist数据
    this.getHomeGoods("new");
    this.getHomeGoods("sell");
  },
  mounted() {
    this.refresh = debounce(this.$refs.scroll.refresh); // 防抖
    Bus.$on("refreshFromHomeSwiper", () => {
      this.refresh();
    });
    Bus.$on("refreshFromHomeGoodsListItem", () => {
      this.refresh();
    });
    // this.keepPositionY();
  },
  methods: {
    // 事件监听相关方法
    setIndex(index) {
      // console.log(index);
      switch (index) {
        case 0:
          this.currentType = "pop";
          break;
        case 1:
          this.currentType = "new";
          break;
        case 2:
          this.currentType = "sell";
          break;
      }

      this.$refs.tabControl.currentIndex = index;
      this.$refs.topTabControl.currentIndex = index;

      if (this.topTabControlIsShow && this.tabCurrentIndex != index) {
        this.$refs.scroll.scrollTo(0, -this.tabControlOffsetTop, 0);
        this.tabCurrentIndex = index;
      }
    },
    scroll(positionY) {
      // console.log(positionY);
      this.BackTopIsShow = -positionY > 300;
      this.topTabControlIsShow = -positionY >= this.tabControlOffsetTop;
    },
    pullingUp() {
      Indicator.open();
      this.getHomeGoods(this.currentType);
      this.$refs.scroll.finishPullUp();
    },
    refreshBS() {
      this.refresh();
    },
    backToTop() {
      this.$refs.scroll.scrollTo(0, 0);
    },
    getTabControlOffsetTop() {
      this.tabControlOffsetTop = this.$refs.tabControl.$el.offsetTop;
    },

    // 网络请求相关方法
    getHomeMultidata() {
      getHomeMultidata().then((res) => {
        if (res) {
          // console.log(res);
          const data = res.data;
          this.swiperImages = data.banner.list; // 轮播图数据
          this.recommend = res.data.recommend.list; // 轮播图下面的四个推荐数据
        }
      });
    },
    getHomeGoods(type) {
      let page = this.goods[type].page + 1;
      getHomeGoods(type, page).then((res) => {
        if (res) {
          // console.log(res);
          this.goods[type].list.push(...res.data.list); // 将新请求下来的数组里面的每一项都push进this.goods[type].list数组里 举例如下面的注释
          this.goods[type].page += 1;
          Indicator.close();

          /*
            const fruits = ['apple', 'banana', 'mango'];
            const newFruits = ['grape', 'watermelon', 'kiwi'];
            fruits.push(...newFruits);

            console.log(fruits); // (6) ["apple", "banana", "mango", "grape", "watermelon", "kiwi"]
            console.log(newFruits); // (3) ["grape", "watermelon", "kiwi"]
          */
        }
      });
    },
  },
  components: {
    NavBar,
    HomeSwiper,
    HomeRecommend,
    HomeFeature,
    TabControl,
    GoodsList,
    Scroll,
    BackTop,
  },
  activated() {
    this.$refs.scroll.refresh();
    this.$refs.scroll.scrollTo(0, this.currentPagePositionY, 0);
  },
  deactivated() {
    this.currentPagePositionY = this.$refs.scroll.bs.y;
    // console.log(this.currentPagePositionY);
  },
};
</script>

<style scoped>
#home {
  padding-top: 44px;
  /* padding-bottom: 49px; */
  /* height: calc(100vh - 49px); */
}

.home-nav-bar {
  background: var(--color-tint);
  color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9;
  font-weight: bold;
}

.home-swiper {
  height: 52vw;
}

.scroll {
  position: relative;
  height: calc(100vh - 93px);
  top: 0;
  background: #fff;
  /* 因为顶部栏44px 底部栏49px 这里要加起来一起算为93px */
}

.top-tab-control {
  position: fixed;
  top: 44px;
  left: 0;
  right: 0;
  margin-bottom: 4px;
  z-index: 9;
}

.goods-list {
  margin-top: 4px;
}
</style>

<style>
.mint-indicator-wrapper {
  background: rgba(255, 255, 255, 0.7);
}
.mint-spinner-snake {
  border-top-color: var(--color-high-text) !important;
  border-bottom-color: var(--color-high-text) !important;
  border-left-color: var(--color-high-text) !important;
}
</style>