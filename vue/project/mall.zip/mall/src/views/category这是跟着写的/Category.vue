<template>
  <div id="category">
    <nav-bar class="category-nav-bar">
      <template v-slot:center>
        商品分类
      </template>
    </nav-bar>

    <div class="main-content">
      <div class="wrap left-wrap">
        <tab-menu :categories="categories" @setIndex="setIndex"></tab-menu>
      </div>

      <div class="wrap right-wrap">
        <second-scroll class="right-scroll" ref="rightScroll">
          <tab-content-category :subcategories="showSubcategory" @refreshBS="refreshBS" />

          <tab-control :titles="['综合', '新品', '销量']" @setIndex="itemClick" ref="tabControl" />

          <tab-content-detail :category-detail="showCategoryDetail" />
        </second-scroll>
      </div>
    </div>

  </div>
</template>

<script>
// 导入公共组件
import NavBar from "components/common/navBar/NavBar";
import SecondScroll from "components/common/scroll/SecondScroll";
import TabControl from "components/content/tabControl/TabControl";

// 导入子组件
import TabMenu from "./categoryChildren/TabMenu";
import TabContentCategory from "./categoryChildren/TabContentCategory";
import TabContentDetail from "./categoryChildren/TabContentDetail";

// / 导入网络请求相关方法
import {
  getCategory,
  getSubcategory,
  getCategoryDetail,
} from "network/category";

// 导入公共JS模块
import { debounce } from "common/utils"; // 防抖函数

export default {
  name: "Category",
  data() {
    return {
      categories: [],
      currentIndex: -1,
      categoryData: {}, // categoryData里面有index个对象 每个index对象有subcategories和categoryDetail两个属性 其中每个categoryDetail有3个属性pop new sell
      refresh: null,
      currentType: "pop",
    };
  },
  created() {
    // console.log("Category created");
    // 请求分类数据
    this.getCategory();
  },
  mounted() {
    this.refresh = debounce(this.$refs.rightScroll.refresh);
  },
  computed: {
    showSubcategory() {
      if (this.currentIndex == -1) {
        return {};
      }
      return this.categoryData[this.currentIndex].subcategories;
    },
    showCategoryDetail() {
      if (this.currentIndex == -1) {
        return [];
      }
      return this.categoryData[this.currentIndex].categoryDetail[
        this.currentType
      ];
    },
  },
  methods: {
    // 事件监听相关方法
    setIndex(index) {
      // console.log(index);
      this.getSubcategory(index);
      this.$refs.tabControl.currentIndex = 0;
    },
    refreshBS() {
      this.refresh();
    },
    itemClick(index) {
      // console.log(index);
      switch (index) {
        case 0:
          this.currentType = "pop";
          break;
        case 1:
          this.currentType = "new";
          break;
        case 2:
          this.currentType = "sell";
          break;
      }
      // console.log(this.currentType);
    },

    // 网络请求相关方法
    getCategory() {
      getCategory().then((res) => {
        if (res) {
          const data = res.data;
          // console.log(data);
          this.categories = data.category.list;
          this.categories.forEach((element, index) => {
            // 初始化categoryData对象
            this.categoryData[index] = {
              subcategories: {},
              categoryDetail: {
                pop: [],
                new: [],
                sell: [],
              },
            };
          });
        }
        this.getSubcategory(0);
      });
    },
    getSubcategory(index) {
      this.currentIndex = index;
      const maitKey = this.categories[index].maitKey;
      getSubcategory(maitKey).then((res) => {
        if (res) {
          console.log(res);
          this.categoryData[index].subcategories = res.data;
          this.categoryData = { ...this.categoryData }; // 实行浅拷贝
          this.getCategoryDetail("pop");
          this.getCategoryDetail("new");
          this.getCategoryDetail("sell");
        }
      });
    },
    getCategoryDetail(type) {
      const miniWallkey = this.categories[this.currentIndex].miniWallkey;
      getCategoryDetail(miniWallkey, type).then((res) => {
        if (res) {
          // console.log(res);
          this.categoryData[this.currentIndex].categoryDetail[type] = res;
          this.categoryData = { ...this.categoryData };
        }
      });
    },
  },
  components: {
    NavBar,
    TabMenu,
    SecondScroll,
    TabContentCategory,
    TabControl,
    TabContentDetail,
  },
  activated() {
    this.refresh();
  },
};
</script>

<style scoped>
#category {
  height: calc(100vh - 49px);
}

.category-nav-bar {
  background: var(--color-tint);
  color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9;
  font-weight: bold;
}

.main-content {
  height: calc(100% - 44px);
  position: relative;
  top: 44px;
  display: flex;
}

.wrap {
  height: 100%;
}

.left-wrap {
  width: 100px;
}

.right-wrap {
  flex-grow: 1;
  /* background: #4f4; */
}
.right-scroll {
  height: 100%;
}
</style>