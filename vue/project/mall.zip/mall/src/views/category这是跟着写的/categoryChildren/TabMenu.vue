<template>
  <scroll class="left-scroll">
    <ul calss="tab-list">
      <li v-for="(item, index) in categories" 
          :key="index" 
          class="tab-list-item" 
          :class="{active:currentIndex==index}" 
          @click="setIndex(index)">
        {{item.title}}
      </li>
    </ul>
  </scroll>
</template>

<script>
// 导入公共组件
import Scroll from "components/common/scroll/Scroll";

export default {
  name: "TabMenu",
  props: {
    categories: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      currentIndex: 0,
    };
  },
  methods: {
    setIndex(index) {
      this.currentIndex = index;
      this.$emit("setIndex", index);
    },
  },
  components: {
    Scroll,
  },
};
</script>

<style scoped>
.left-scroll {
  width: 100px;
  height: 100%;
  background: #f6f6f6;
  box-sizing: border-box;
}

.tab-list {
  list-style: none;
}

.tab-list-item {
  height: 45px;
  line-height: 45px;
  text-align: center;
  font-size: 14px;
}

.active {
  font-weight: bold;
  color: var(--color-high-text);
  background-color: #fff;
  border-left: 3px solid var(--color-high-text);
}
</style>