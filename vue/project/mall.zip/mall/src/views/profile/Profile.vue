<template>
  <div id="profile">
    <nav-bar class="profile-nav-bar">
      <template v-slot:center>
        <div>
          我的
        </div>
      </template>
    </nav-bar>

    <user-info />

    <div class="general">
      <list-view :list="orderList" />
    </div>

    <list-view :list="serviceList" />
  </div>
</template>

<script>
// 导入公共组件
import NavBar from "components/common/navBar/NavBar";

// 导入子组件
import UserInfo from "./profileChildren/UserInfo";
import ListView from "./profileChildren/ListView";

export default {
  name: "Profile",
  created() {
    // console.log("Profile created");
  },
  data() {
    return {
      orderList: [
        { icon: "icon-xiaoxi", iconColor: "#ff8198", info: "我的消息" },
        {
          icon: "icon-jifenshangcheng",
          iconColor: "#fc7b53",
          info: "积分商城",
        },
        { icon: "icon-huangguan", iconColor: "#ffc636", info: "会员卡" },
      ],
      serviceList: [
        { icon: "icon-gouwuchekong", iconColor: "#ff8198", info: "我的购物车" },
        { icon: "icon-elment", iconColor: "#ff8198", info: "下载购物APP" },
      ],
    };
  },
  components: {
    NavBar,
    UserInfo,
    ListView,
  },
};
</script>

<style scoped>
#profile {
  background: #fff;
}
.profile-nav-bar {
  background: var(--color-tint);
  color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9;
  font-weight: bold;
}
.general {
  border-bottom: 12px solid #eee;
}
</style>