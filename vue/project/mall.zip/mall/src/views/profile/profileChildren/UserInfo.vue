<template>
  <div id="user-info">
    <div class="top">
      <div class="img-wrap">
        <img src="@/assets/img/profile-holder.jpg" alt="">
      </div>
      <div class="login-wrap">
        <a href="#">登录</a>/
        <a href="#">注册</a>
        <div class="phone">
          <i class="iconfont icon-shouji"></i>
          暂无绑定手机号</div>
      </div>
      <div class="check-profile">
        <span class="iconfont icon-gengduo"></span>
      </div>
    </div>
    <div class="bottom">
      <a class="bottom-item">
        <span class="num">0.00</span>元
        <div class="bottom-txt">我的余额</div>
      </a>
      <a class="bottom-item">
        <span class="num">0</span>个
        <div class="bottom-txt">我的优惠</div>
      </a>
      <a class="bottom-item">
        <span class="num">0</span>分
        <div class="bottom-txt">我的积分</div>
      </a>
    </div>
  </div>
</template>

<script>
export default {
  name: "UserInfo",
};
</script>

<style scoped>
#user-info {
  margin-top: 44px;
  border-bottom: 12px solid #eee;
}
.top {
  background: var(--color-tint);
  height: 90px;
  display: flex;
  color: #fff;
  padding: 12px 15px;
}
.img-wrap {
  height: 62px;
  width: 62px;
  background: #fff;
  border-radius: 50%;
  margin-right: 12px;
  overflow: hidden;
}
.img-wrap img {
  width: 100%;
}
.login-wrap {
  padding-top: 10px;
}
.check-profile {
  height: 100%;
  display: flex;
  align-items: center;
  margin-left: auto;
}
.top a {
  color: #fff;
}
.phone {
  font-size: 14px;
  margin-top: 4px;
}

.bottom {
  height: 82px;
  display: flex;
}
.bottom-item {
  flex: 1;
  text-align: center;
  display: block;
  padding-top: 16px;
}
.bottom-item:nth-child(2) {
  border-left: 1px solid #eee;
  border-right: 1px solid #eee;
}
.num {
  color: #ff5f3e;
  font-weight: bold;
  font-size: 22px;
}
.bottom-txt {
  font-size: 14px;
  margin-top: 4px;
}
.iconfont {
  font-size: 14px;
}
</style>