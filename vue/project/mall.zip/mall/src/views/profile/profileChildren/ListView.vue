<template>
  <div class="list-view">
    <ul class="list">
      <li class="list-item" v-for="(item, index) in list" :key="index">
        <div class="item-icon-wrap">
          <span class="iconfont" :class="item.icon" :style="{color:item.iconColor}"></span>
        </div>
        <div class="icon-txt">
          {{item.info}}
        </div>
      </li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "ListView",
  props: {
    list: {
      type: Array,
      default() {
        return [];
      },
    },
  },
};
</script>

<style scoped>
.list {
  list-style: none;
  font-size: 14px;
}
.list-item {
  height: 46px;
  line-height: 46px;
  display: flex;
}
.item-icon-wrap {
  width: 46px;
  /* background: red; */
  text-align: center;
  padding-left: 10px;
  height: 46px;
}
.iconfont {
  font-size: 16px;
  font-weight: bold;
}
.icon-txt {
  border-bottom: 1px solid #eee;
  flex: 1;
  padding-left: 8px;
}
</style>