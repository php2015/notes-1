<template>
    <ul class="tab-list">
      <li class="tab-list-item" v-for="(item, index) in categories" :key="index" @click="setIndex(index)" :class="{active:currentIndex==index}">
        {{item.title}}
      </li>
    </ul>
</template>

<script>
export default {
  name: "TabMenu",
  props: {
    categories: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  data() {
    return {
      currentIndex: 0,
    };
  },
  methods: {
    setIndex(index) {
      this.currentIndex = index;
      this.$emit("setIndex", index);
    },
  },
};
</script>

<style scoped>
.tab-list {
  list-style: none;
}

.tab-list-item {
  height: 45px;
  line-height: 45px;
  text-align: center;
  font-size: 14px;
}

.active {
  font-weight: bold;
  color: var(--color-high-text);
  background-color: #fff;
  border-left: 3px solid var(--color-high-text);
}
</style>