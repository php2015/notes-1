<template>
  <div class="tab-content-category">
    <ul class="list">
      <li v-for="(item, index) in subcategories.list" :key="index">
        <a :href="item.link" class="item-wrap">
          <img class="item-image" :src="item.image" alt="" @load="refreshBS">
          <div class="item-txt">{{item.title}}</div>
        </a>
      </li>
      <li v-if="listLength%3==1 || listLength%3==2"></li>
       <li v-if="listLength%3==1"></li>
    </ul>
  </div>
</template>

<script>
export default {
  name: "TabContentCategory",
  props: {
    subcategories: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  computed: {
    listLength() {
      if (Object.keys(this.subcategories).length == 0) {
        return 0;
      } else {
        return this.subcategories.list.length;
      }
    },
  },
  methods: {
    refreshBS() {
      this.$emit("refreshBS");
    },
  },
};
</script>

<style scoped>
.tab-content-category {
  padding: 10px;
}

.list {
  list-style: none;
  display: flex;
  flex-flow: row wrap;
  justify-content: space-evenly;
  text-align: center;
  font-size: 12px;
  width: 100%;
}
.list > li {
  width: 28%;
  margin-bottom: 20px;
}
.item-image {
  width: 100%;
}
.item-txt {
  margin-top: 8px;
}
.item-wrap {
  display: block;
}
</style>