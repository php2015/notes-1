<template>
  <div class="tab-content-detail">
    <goods-list :items="categoryDetail" />
  </div>
</template>

<script>
import GoodsList from "components/content/goods/GoodsList";

export default {
  name: "TabContentDetail",
  props: {
    categoryDetail: {
      type: Array,
      default() {
        return [];
      },
    },
  },
  components: {
    GoodsList,
  },
};
</script>

<style scoped>
.tab-content-detail {
  width: calc(100vw - 100px);
}
</style>