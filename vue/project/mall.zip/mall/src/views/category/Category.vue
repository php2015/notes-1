<template>
  <div id="category">
    <nav-bar class="category-nav-bar">
      <template v-slot:center>
        <div>商品分类</div>
      </template>
    </nav-bar>

    <div class="main-content">
      <scroll class="scroll left-scroll" ref="scroll">
        <tab-menu :categories="categories" @setIndex="setIndex" />
      </scroll>
      <second-scroll class="scroll right-scroll" ref="secondScroll">
        <tab-content-category :subcategories="showSubcategory" @refreshBS="refreshBS" />
        <tab-control :titles="['综合', '新品', '销量']" @setIndex="itemClick" ref="tabControl" />
        <tab-content-detail :category-detail="showCategoryDetail" />
      </second-scroll>
    </div>
  </div>
</template>

<script>
// 导入公共组件
import NavBar from "components/common/navBar/NavBar";
import Scroll from "components/common/scroll/Scroll";
import SecondScroll from "components/common/scroll/SecondScroll";
import TabControl from "components/content/tabControl/TabControl";
import GoodsList from "components/content/goods/GoodsList";

// 导入子组件
import TabMenu from "./categoryChildren/TabMenu";
import TabContentCategory from "./categoryChildren/TabContentCategory";
import TabContentDetail from "./categoryChildren/TabContentDetail";

// 导入网络请求相关方法
import {
  getCategory,
  getSubcategory,
  getCategoryDetail,
} from "network/category";

// 导入公共JS模块
import { debounce } from "common/utils"; // 防抖函数
import Bus from "common/bus";

export default {
  name: "Category",
  components: {
    NavBar,
    Scroll,
    SecondScroll,
    TabMenu,
    TabContentCategory,
    TabControl,
    GoodsList,
    TabContentDetail,
  },
  data() {
    return {
      categories: [],
      categoryData: {},
      currentType: "pop",
      currentIndex: -1,
      refresh: null,
    };
  },
  created() {
    this.getCategory();
  },
  mounted() {
    this.refresh = debounce(this.$refs.secondScroll.refresh);
    Bus.$on("categoryRefresh", () => {
      this.refresh();
    });
  },
  computed: {
    showSubcategory() {
      if (this.currentIndex == -1) {
        return {};
      }
      return this.categoryData[this.currentIndex].subcategories;
    },
    showCategoryDetail() {
      if (this.currentIndex == -1) {
        return [];
      }
      return this.categoryData[this.currentIndex].categoryDetail[
        this.currentType
      ];
    },
  },
  methods: {
    // 事件监听相关方法
    setIndex(index) {
      // console.log(index);
      this.getSubcategory(index);
      this.$refs.tabControl.currentIndex = 0;
    },
    refreshBS() {
      this.refresh();
    },
    itemClick(index) {
      switch (index) {
        case 0:
          this.currentType = "pop";
          break;
        case 1:
          this.currentType = "new";
          break;
        case 2:
          this.currentType = "sell";
          break;
      }
      console.log(this.currentType);
    },

    // 网络请求相关方法
    getCategory() {
      getCategory().then((res) => {
        if (res) {
          const data = res.data;
          // console.log(data);
          // console.log(data.category.list);
          this.categories = data.category.list;
          this.categories.forEach((element, index) => {
            this.categoryData[index] = {
              subcategories: {},
              categoryDetail: {
                pop: [],
                new: [],
                sell: [],
              },
            };
          });
          this.getSubcategory(0);
        }
      });
    },
    getSubcategory(index) {
      this.currentIndex = index;
      const maitKey = this.categories[index].maitKey;
      getSubcategory(maitKey).then((res) => {
        if (res) {
          // console.log(res);
          this.categoryData[index].subcategories = res.data;
          this.categoryData = { ...this.categoryData }; // 为什么要拷贝一下？上面[index]这样操作 数据的确是有了 但是没有实现数据绑定

          this.getCategoryDetail("pop");
          this.getCategoryDetail("new");
          this.getCategoryDetail("sell");
        }
      });
    },
    getCategoryDetail(type) {
      const miniWallkey = this.categories[this.currentIndex].miniWallkey;
      getCategoryDetail(miniWallkey, type).then((res) => {
        if (res) {
          // console.log(res);
          this.categoryData[this.currentIndex].categoryDetail[type] = res;
          this.categoryData = { ...this.categoryData };
        }
      });
    },
  },
  activated() {
    this.$refs.scroll.refresh();
    this.$refs.secondScroll.refresh();
  },
};
</script>

<style scoped>
#category {
  height: calc(100vh - 49px);
}

.category-nav-bar {
  background: var(--color-tint);
  color: #fff;
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  z-index: 9;
  font-weight: bold;
}

.main-content {
  height: calc(100% - 44px);
  position: relative;
  top: 44px;
  display: flex;
}

.scroll {
  height: 100%;
}

.left-scroll {
  width: 100px;
  background: #f6f6f6;
  box-sizing: border-box;
}

.right-scroll {
  flex: 1;
  /* background: #44f; */
}
</style>