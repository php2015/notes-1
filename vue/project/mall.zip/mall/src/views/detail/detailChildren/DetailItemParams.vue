<template>
  <div class="item-params">
    
    <div class="size">
      <table class="size-table" border="1">
        <tbody>
          <tr v-for="(rows, index) in itemParams.tables" :key="index" class="rows">
            <td v-for="(item, indey) in rows" :key="indey">
              {{item}}
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <div class="params">
      <table class="params-table" border="1">
        <tr v-for="(rows, index) in itemParams.set" :key="index" class="rows">
          <td class="rows-key">{{rows.key}}</td>
          <td class="rows-value">{{rows.value}}</td>
        </tr>
      </table>
    </div>

    <div class="img-wrap" v-if="itemParams.images">
      <img :src="itemParams.images" alt="">
    </div>

  </div>
</template>

<script>
export default {
  name: "DetailItemParams",
  props: {
    itemParams: {
      type: Object,
      default() {
        return {};
      },
    },
  },
};
</script>

<style scoped>
.item-params {
  border-bottom: 6px solid #eee;
}
.size {
  padding: 20px 40px;
}
.size-table {
  width: 100%;
  border-bottom: 3px solid #eee;
  text-align: center;
}
.size-table td {
  width: 25%;
  padding: 6px;
  border: none;
}
.params {
  padding: 20px;
}
.params-table {
  width: 100%;
}
.params-table td {
  padding: 6px;
  border: none;
}
.rows-key {
  width: 30%;
}

table {
  border-collapse: collapse;
  border-color: #fff;
  border: none;
}
.rows {
  border-bottom: 1px solid #eee;
}
.rows-value {
  color: var(--color-tint);
}
.img-wrap img {
  width: 100%;
}
</style>