<template>
  <div class="detail-nav-bar">
    <nav-bar>
      <template v-slot:left>
        <div class="back-wrap">
          <span class="iconfont icon-fanhui" @click="back"></span>
        </div>
      </template>
      <template v-slot:center>
        <div class="title-wrap">
          <span v-for="(title, index) in titles" :key="index" class="title" @click="setIndex(index)" :class="{active:currentIndex==index}">{{title}}</span>
        </div>
      </template>
    </nav-bar>
  </div>
</template>

<script>
// 导入公共组件
import NavBar from "components/common/navBar/NavBar";

export default {
  name: "DetailNavBar",
  components: {
    NavBar,
  },
  props: {},
  data() {
    return {
      titles: ["商品", "参数", "评论", "推荐"],
      currentIndex: 0,
    };
  },
  methods: {
    setIndex(index) {
      this.currentIndex = index;
      this.$emit("setIndex", index);
    },
    back() {
      this.$router.back();
    },
  },
};
</script>

<style scoped>
.title-wrap {
  display: flex;
  font-size: 13px;
}

.title {
  flex: 1;
}

.back-wrap {
  display: flex;
}

.icon-fanhui {
  flex: 1;
}

.icon-fanhui:active {
  color: var(--color-high-text);
}

.active {
  color: var(--color-high-text);
  font-weight: bold;
}
</style>