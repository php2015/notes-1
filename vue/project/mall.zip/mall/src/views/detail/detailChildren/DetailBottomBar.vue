<template>
  <div class="bottom-bar">
    <div class="left">
      <div>
        <span class="iconfont icon-kefu"></span>
        <p>客服</p>
      </div>
      <div>
        <span class="iconfont icon-dianpu"></span>
        <p>店铺</p>
      </div><div>
        <span class="iconfont icon-shoucang"></span>
        <p>收藏</p>
      </div>
    </div>
    <div class="right">
      <div class="add-to-cart" @click.self="addToCart">加入购物车</div>
      <div class="purchase">购买</div>
    </div>
  </div>
</template>

<script>
export default {
  name: "DetailBottomBar",
  data() {
    return {
      addToCartIsAllowed: true,
    };
  },
  methods: {
    addToCart() {
      // this.addToCartIsAllowed = true;
      if (this.addToCartIsAllowed) {
        this.$emit("addToCart");
        this.addToCartIsAllowed = false;
        setTimeout(() => {
          this.addToCartIsAllowed = true;
        }, 1000);
      }
    },
  },
};
</script>


<style scoped>
.bottom-bar {
  position: fixed;
  left: 0;
  right: 0;
  bottom: 0;
  background: #fff;
  height: 49px;
  display: flex;
  box-shadow: 0px -2px 1px rgba(100, 100, 100, 0.1);
}
.left {
  width: 50%;
  display: flex;
  text-align: center;
}
.left > div {
  flex: 1;
  padding-top: 6px;
}
.left > div p {
  margin-top: 2px;
  font-size: 14px;
}
.right {
  width: 50%;
  display: flex;
  text-align: center;
  line-height: 49px;
}
.right > div {
  flex: 1;
  font-size: 14px;
}
.add-to-cart {
  background: #ff4;
}
/* .add-to-cart:active {
  color: #fff;
} */
.purchase {
  background: var(--color-high-text);
  color: #fff;
}
</style>