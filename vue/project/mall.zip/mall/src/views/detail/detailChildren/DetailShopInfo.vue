<template>
  <div class="shop-info">

    <div class="shop-wrap">
      <div class="shop-logo"><img :src="shopInfo.shopLogo" alt="" @load="refreshBS"></div>
      <h3>{{shopInfo.name}}</h3>
    </div>

    <div class="shop-detail">
      <div class="shop-left">
        <div class="shop-sales">
          <h3>{{shopInfo.sales | salesFormat}}</h3>
          <span>总销量</span>
        </div>
        <div class="goods-amount">
          <h3>{{shopInfo.goodsCount | salesFormat}}</h3>
          <span>全部宝贝</span>
        </div>
      </div>
      <div class="shop-right">
        <div v-for="(item, index) in shopInfo.score" :key="index">
          <span class="item-name">{{item.name}}</span>
          <span :class="{high:item.isBetter}" class="item-score">{{item.score}}</span>
          <span class="comment" :class="{'bg-high':item.isBetter}">{{item.isBetter?'高':'低'}}</span>
        </div>
      </div>
    </div>

    <div class="browse-shop">
      进店逛逛
    </div>

  </div>
</template>

<script>
export default {
  name: "DetailShopInfo",
  props: {
    shopInfo: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  filters: {
    salesFormat(n) {
      return n >= 10000 ? (n / 10000).toFixed(1) + "万" : n;
    },
  },
  methods: {
    refreshBS() {
      this.$emit("refreshBS");
    },
  },
};
</script>

<style scoped>
.shop-info {
  padding: 0px 14px 0px;
  /* background: red; */
  border-bottom: 6px solid #eee;
}
.shop-wrap {
  display: flex;
  align-items: center;
  margin-top: 34px;
  margin-bottom: 34px;
}
.shop-logo {
  width: 56px;
  height: 56px;
  border-radius: 50%;
  overflow: hidden;
  border: 1px solid #ccc;
  margin-right: 12px;
}
.shop-logo img {
  width: 100%;
}
.shop-detail {
  display: flex;
  align-items: center;
}
.shop-left {
  display: flex;
  border-right: 2px solid #ccc;
  justify-content: space-evenly;
  width: 50%;
  text-align: center;
}
.shop-sales h3 {
  margin-bottom: 8px;
}
.goods-amount h3 {
  margin-bottom: 8px;
}
.shop-sales span,
.goods-amount span {
  font-size: 14px;
}

.comment {
  color: #fff;
}
.item-score {
  color: #4a4;
}
.comment {
  background: #4a4;
}
.high {
  color: var(--color-high-text);
}
.bg-high {
  background: var(--color-high-text);
}
.shop-right {
  padding-top: 12px;
  padding-bottom: 12px;
  width: 50%;
  /* background: red; */
}
.shop-right > div:nth-child(2) {
  margin-top: 10px;
  margin-bottom: 10px;
}
.shop-right > div {
  display: flex;
  justify-content: space-between;
  padding-left: 34px;
  padding-right: 16px;
  font-size: 15px;
}
.browse-shop {
  padding: 8px 50px;
  background: #f1f5fb;
  margin: 15px auto 30px;
  width: fit-content;
  border-radius: 6px;
}
</style>