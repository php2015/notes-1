<template>
  <div class="detail-info">
    <div class="desc">{{detailInfo.desc}}</div>


    <div v-for="(item, index) in detailInfo.detailImage" :key="index">
      <h3 v-if="item.list">{{item.key}}：</h3>
      <img :src="image" alt="" v-for="(image, index) in item.list" :key="index"  @load="refreshBS">
    </div>

  </div>
</template>

<script>
export default {
  name: "DetailInfo",
  props: {
    detailInfo: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  methods: {
    refreshBS() {
      this.$emit("refreshBS");
    },
  },
};
</script>

<style scoped>
.detail-info {
  border-bottom: 6px solid #eee;
}
.detail-info h3 {
  padding: 0 20px;
  font-size: 16px;
  margin-top: 20px;
  color: var(--color-high-text);
  margin-bottom: 8px;
}
.detail-info img {
  width: 100%;
}
.desc {
  padding: 20px;
}
</style>