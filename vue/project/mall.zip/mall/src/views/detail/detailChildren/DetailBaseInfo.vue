<template>
  <div class="base-info" v-if="Object.keys(baseInfo).length!=0">
    <h3 class="info-title">{{baseInfo.title}}</h3>

    <div class="info-price">
      <span class="price">{{baseInfo.lowNowPrice | cnyFormat}}</span>
      <del class="old-price grey" v-if="baseInfo.oldPrice">{{baseInfo.oldPrice}}</del>
      <sup class="discount-desc" v-if="baseInfo.discountDesc">{{baseInfo.discountDesc}}</sup>
    </div>

    <div class="columns-wrap grey">
      <span v-for="(item, index) in columns" :key="index">{{item}}</span>
      <span>{{baseInfo.services[baseInfo.services.length-1].name}}</span>
    </div>

    <div class="services-wrap">
      <div v-for="(item, index) in services" :key="index">
        <img :src="item.icon" alt=""> 
        <span>{{item.name}}</span>
      </div>
    </div>

  
  </div>
</template>

<script>
export default {
  name: "DetailBaseInfo",
  props: {
    baseInfo: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  computed: {
    columns() {
      const length = this.baseInfo.columns.length;
      return this.baseInfo.columns.slice(0, length - 1);
    },
    services() {
      const length = this.baseInfo.services.length;
      return this.baseInfo.services.slice(0, length - 1);
    },
  },
  filters: {
    cnyFormat(n) {
      return "¥" + n;
    },
  },
};
</script>

<style scoped>
.base-info {
  border-bottom: 6px solid #eee;
}

.info-title {
  padding: 14px 12px 14px;
  font-weight: normal;
  font-size: 18px;
}

.info-price {
  padding: 0px 14px 6px;
}

.info-price .price {
  color: var(--color-high-text);
  font-size: 24px;
  margin-right: 4px;
}

.info-price .old-price {
  font-size: 14px;
  margin-right: 4px;
}

.info-price .discount-desc {
  font-size: 14px;
  background: var(--color-high-text);
  padding: 4px 6px;
  border-radius: 10px;
  color: #fff;
}

.grey {
  color: #aaa;
}

.columns-wrap,
.services-wrap {
  display: flex;
  font-size: 14px;
  text-align: center;
}

.columns-wrap {
  margin-top: 14px;
  border-bottom: 1px solid #eee;
  margin-left: 14px;
  margin-right: 14px;
  padding-bottom: 6px;
}

.services-wrap {
  padding: 20px 14px;
}

.columns-wrap span,
.services-wrap > div {
  flex: 1;
}

.columns-wrap span:first-child,
.services-wrap > div:first-child {
  text-align: left;
}

.columns-wrap span:last-child,
.services-wrap > div:last-child {
  text-align: right;
}

.services-wrap img {
  width: 12px;
  margin-right: 2px;
}
</style>