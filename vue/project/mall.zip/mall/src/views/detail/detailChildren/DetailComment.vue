<template>
  <div class="comment">

    
    <div class="comment-header">
      <span>用户评价</span>
      <i class="more" v-show="Object.keys(firstComment).length">更多</i>
    </div>

    <div v-if="Object.keys(firstComment).length">
      <div class="user-info">
        <img :src="firstCommentUser.avatar" alt="" @load="refreshBS">
        <span>{{firstCommentUser.uname}}</span>
      </div>

      <div class="content">
        {{firstComment.content}}
      </div>

      <div class="comment-bottom">
        <span class="date">{{dateCreated}}</span>
        <span class="style">{{firstComment.style}}</span>
      </div>

      <div class="comment-img" v-if="firstComment.images">
        <img :src="item" alt="" v-for="(item, index) in firstComment.images" :key="index" @load="refreshBS">
      </div>
    </div>

    <div v-else class="no-comment">
      暂无评论。
    </div>
  </div>
  
</template>

<script>
import { showDateWithFormat } from "common/moment";

export default {
  name: "DetailComment",
  props: {
    firstComment: {
      type: Object,
      default() {
        return {};
      },
    },
    firstCommentUser: {
      type: Object,
      default() {
        return {};
      },
    },
  },
  computed: {
    dateCreated() {
      return showDateWithFormat(
        new Date(this.firstComment.created * 1000),
        "YYYY-MM-DD"
      );
    },
  },
  methods: {
    refreshBS() {
      this.$emit("refreshBS");
    },
  },
};
</script>

<style scoped>
.comment {
  border-bottom: 6px solid #eee;
  padding: 20px;
}
.comment-header {
  display: flex;
  height: 44px;
  line-height: 44px;
  justify-content: space-between;
  border-bottom: 2px solid #eee;
}
.user-info {
  height: 44px;
  line-height: 44px;
  /* background: red; */
  margin-top: 12px;
  margin-bottom: 12px;
}
.user-info img {
  height: 44px;
  vertical-align: middle;
  margin-right: 12px;
}
.content {
  font-size: 14px;
  margin-top: 8px;
  margin-bottom: 12px;
}
.comment-bottom {
  margin-top: 8px;
  font-size: 14px;
}
.date {
  margin-right: 8px;
}
.more {
  font-size: 14px;
}
.comment-img {
  margin-top: 8px;
}
.comment-img img {
  height: 80px;
  margin-right: 10px;
}
.no-comment {
  padding-top: 20px;
  font-size: 14px;
}
</style>