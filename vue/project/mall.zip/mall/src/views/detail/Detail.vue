<template>
  <div id="detail">

    <detail-nav-bar class="detail-nav-bar" @setIndex="setIndex" ref="detailNavBar" />

    <scroll class="scroll" ref="scroll" @scroll="scroll" :probe-type="3">
      <swiper :swiperImages="swiperImages" class="swiper" />
      <detail-base-info :baseInfo="baseInfo" />
      <detail-shop-info :shopInfo="shopInfo" @refreshBS="refreshBS" />
      <detail-info :detail-info="detailInfo" @refreshBS="refreshBS" />
      <detail-item-params :item-params="itemParams" ref="params" />
      <detail-comment ref="comment" :first-comment="firstComment" :first-comment-user="firstCommentUser" @refreshBS="refreshBS" />
      <goods-list :header-is-show="true" :items="goodsList" ref="list" />
    </scroll>
    
    <back-top @click.native="backToTop" v-show="BackTopIsShow" />
    <detail-bottom-bar @addToCart="addToCart" />
  </div>
</template>

<script>
// 导入子组件
import DetailNavBar from "./detailChildren/DetailNavBar";
import DetailBaseInfo from "./detailChildren/DetailBaseInfo";
import DetailShopInfo from "./detailChildren/DetailShopInfo";
import DetailInfo from "./detailChildren/DetailInfo";
import DetailItemParams from "./detailChildren/DetailItemParams";
import DetailComment from "./detailChildren/DetailComment";
import DetailBottomBar from "./detailChildren/DetailBottomBar";

// 导入公共组件
import Swiper from "components/common/swiperFromMint-UI/Swiper";
import GoodsList from "components/content/goods/GoodsList";
import Scroll from "components/common/scroll/Scroll";
import BackTop from "components/content/backTop/BackTop";

// 导入网络请求相关方法
import {
  getDetail,
  BaseInfo,
  Shop,
  itemParams,
  getRecommed,
} from "network/detail";

// 导入公共JS模块
import Bus from "common/bus"; // 中央事件总线
import { debounce } from "common/utils"; // 防抖函数
import { Toast } from "mint-ui";

// 导入vuex相关
import { mapState } from "vuex";

export default {
  name: "Detail",
  data() {
    return {
      iid: "",
      swiperImages: [], // 轮播图图片数据
      baseInfo: {}, // 商品基本信息
      shopInfo: {}, // 店铺信息
      detailInfo: {}, // 图片展示
      itemParams: {}, // 商品参数
      firstComment: {}, // 首条评论
      firstCommentUser: {}, // 首条评论的用户信息
      goodsList: [], // 下方推荐数据
      refresh: null,
      BackTopIsShow: false,
      offsetTops: [0, 0, 0, 0], // 商品 参数 评论 推荐的锚点
      getOffsetTops: null,
      currentIndex: 0,
    };
  },
  computed: {
    ...mapState(["cartList"]),
  },
  created() {
    // console.log("Detail created");
    this.iid = this.$route.params.iid;
    // 根据iid发送网络请求
    getDetail(this.iid).then((res) => {
      if (res) {
        // console.log(res);
        const data = res.result;
        this.swiperImages = data.itemInfo.topImages; // 请求轮播图数据

        this.baseInfo = new BaseInfo( // 商品基本信息
          data.itemInfo,
          data.columns,
          data.shopInfo.services
        );

        this.shopInfo = new Shop(data.shopInfo); // 店铺信息

        this.detailInfo = data.detailInfo; // 图片展示

        this.itemParams = new itemParams( // 商品参数
          data.itemParams.info,
          data.itemParams.rule
        );

        if (data.rate.cRate != 0) {
          this.firstComment = data.rate.list[0];
          this.firstCommentUser = data.rate.list[0].user;
        }
      }
    });

    // 下方推荐数据
    getRecommed().then((res) => {
      // console.log(res);
      if (res) {
        this.goodsList = res.data.list;
      }
    });
  },
  mounted() {
    if (this.$refs.scroll) {
      this.refresh = debounce(this.$refs.scroll.refresh, 500);
    }

    // 在图片加载完后获取商品 参数 评论 推荐的offsetTop 因此要防抖
    this.getOffsetTops = debounce(() => {
      this.offsetTops = [];
      if (this.$refs.params && this.$refs.comment && this.$refs.list) {
        this.offsetTops.push(0);
        this.offsetTops.push(this.$refs.params.$el.offsetTop);
        this.offsetTops.push(this.$refs.comment.$el.offsetTop);
        this.offsetTops.push(this.$refs.list.$el.offsetTop);
        this.offsetTops.push(Number.MAX_VALUE);
        // console.log(this.offsetTops);
      }
    }, 100);

    Bus.$on("refreshFromDetailSwiper", () => {
      this.refresh();
      this.getOffsetTops();
    });
    Bus.$on("refreshFromDetailGoodsListItem", () => {
      this.refresh();
      this.getOffsetTops();
    });
  },
  methods: {
    refreshBS() {
      this.refresh();
      this.getOffsetTops();
    },
    backToTop() {
      this.$refs.scroll.scrollTo(0, 0);
    },
    scroll(positionY) {
      this.BackTopIsShow = -positionY > 300;

      let length = this.offsetTops.length;
      for (let i = 0; i < length - 1; i++) {
        if (
          -positionY >= this.offsetTops[i] &&
          -positionY < this.offsetTops[i + 1] &&
          this.currentIndex != i
        ) {
          this.currentIndex = i;
          // console.log(this.currentIndex);
          this.$refs.detailNavBar.currentIndex = this.currentIndex;
        }
      }
    },
    setIndex(index) {
      // console.log(index);
      this.$refs.scroll.scrollTo(0, -this.offsetTops[index]);
    },
    addToCart() {
      // console.log("addToCart");
      const product = {
        iid: this.iid,
        imgURL: this.swiperImages[0],
        title: this.baseInfo.title,
        desc: this.detailInfo.desc,
        lowNowPrice: this.baseInfo.lowNowPrice,
        isChecked: true,
      };
      // console.log(product);
      this.$store.dispatch("addToCart", product).then((res) => {
        // console.log(res);
        Toast({
          message: res,
          // position: "bottom",
          duration: 1000,
        });
      });
    },
  },
  components: {
    DetailNavBar,
    Swiper,
    DetailBaseInfo,
    DetailShopInfo,
    DetailInfo,
    DetailItemParams,
    DetailComment,
    GoodsList,
    Scroll,
    BackTop,
    DetailBottomBar,
  },
  watch: {
    // 数据一旦发现变化 存入localStorage
    cartList: {
      deep: true,
      handler: (newVal) => {
        localStorage.setItem("cart-list", JSON.stringify(newVal));
      },
    },
  },
};
</script>

<style scoped>
#detail {
  position: relative;
  background: #fff;
  z-index: 15;
}

.detail-nav-bar {
  background: #fff;
  position: relative;
  z-index: 20;
}

.swiper {
  height: 100vw;
}

.scroll {
  height: calc(100vh - 44px);
  position: relative;
}
</style>

<style>
.mint-toast {
  background: var(--color-high-text);
  color: #fff;
  /* opacity: 0.7; */
}
</style>